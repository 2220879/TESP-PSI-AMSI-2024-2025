package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class GrelhaFavoritosAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Favorito> favoritos;

    public GrelhaFavoritosAdaptador(Context context, ArrayList<Favorito> favoritos){
        this.context=context;
        this.favoritos=favoritos;
    }

    @Override
    public int getCount() {
        return favoritos.size();
    }

    @Override
    public Object getItem(int i) {
        return favoritos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return favoritos.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        // Verifica se a view já foi criada ou precisa ser inflada
        if (view == null) {
            view = inflater.inflate(R.layout.item_grelha_favoritos, viewGroup, false);
        }

        GrelhaFavoritosAdaptador.ViewHolderLista viewHolder = (GrelhaFavoritosAdaptador.ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new GrelhaFavoritosAdaptador.ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        // Atualiza os dados da view com as informações do favorito
        Favorito favorito = favoritos.get(i);
        viewHolder.update(favorito);

        return view;
    }

    private class ViewHolderLista {
        private ImageView imgProduto;
        private TextView tvNomeProduto, tvPreco;

        public ViewHolderLista(View view) {
            tvNomeProduto = view.findViewById(R.id.tvNomeProduto);
            tvPreco = view.findViewById(R.id.tvPreco);
            imgProduto = view.findViewById(R.id.imgProduto);
        }

        public void update(Favorito f) {
            tvNomeProduto.setText(f.getNomeProduto());
            tvPreco.setText(String.valueOf(f.getPreco()));
            Glide.with(context)
                    .load(f.getImagem())
                    .placeholder(R.drawable.ic_image_produto)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imgProduto);
        }
        /*public void update(Favorito f){
            // Obtém o produto associado ao favorito
            Produto produto = SingletonProdutosGinasio.getInstance(context).getProduto(f.getProduto_id());

            if (produto != null) {
                // Atualiza o nome e o preço do produto
                tvNomeProduto.setText(produto.getNomeProduto());
                tvPreco.setText(String.format("%s €", produto.getPreco()));

                // Carrega a imagem usando Glide
                Glide.with(context)
                        .load(produto.getImagem()) // URL ou caminho da imagem do produto
                        .placeholder(R.drawable.ic_image_produto) // Imagem de placeholder enquanto carrega
                        .diskCacheStrategy(DiskCacheStrategy.ALL) // Cache de todas as versões da imagem
                        .into(imgProduto);
            } else {
                // Se o produto não for encontrado, exibe valores padrão
                tvNomeProduto.setText("Produto não encontrado");
                tvPreco.setText("");
                imgProduto.setImageResource(R.drawable.ic_image_produto); // Placeholder padrão
            }
        }*/
    }
}

