package pt.ipleiria.estg.projeto.produtosginasio.listeners;

public interface ProdutoListener {
    void onRefreshDetalhes(int detalhes);
}
