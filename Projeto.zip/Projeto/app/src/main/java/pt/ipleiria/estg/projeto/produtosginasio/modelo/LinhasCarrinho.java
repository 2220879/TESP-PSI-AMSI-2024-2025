package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class LinhasCarrinho {
    private int id, quantidade, carrinhocompras_id;
    private float precoUnit, valorIva, valorComIva, subtotal;
    private String nomeProduto, tamanhoNome, imagem;

    public LinhasCarrinho(int id, int quantidade, float precoUnit, float valorIva, float valorComIva, float subtotal, int carrinhocompras_id, String nomeProduto, String tamanhoNome, String imagem) {
        this.id = id;
        this.quantidade = quantidade;
        this.precoUnit = precoUnit;
        this.valorIva = valorIva;
        this.valorComIva = valorComIva;
        this.subtotal = subtotal;
        this.carrinhocompras_id = carrinhocompras_id;
        this.nomeProduto = nomeProduto;
        this.tamanhoNome = tamanhoNome;
        this.imagem = imagem;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public int getCarrinhocompras_id() {
        return carrinhocompras_id;
    }

    public void setCarrinhocompras_id(int carrinhocompras_id) {
        this.carrinhocompras_id = carrinhocompras_id;
    }

    public float getPrecoUnit() {
        return precoUnit;
    }

    public void setPrecoUnit(float precoUnit) {
        this.precoUnit = precoUnit;
    }

    public float getValorIva() {
        return valorIva;
    }

    public void setValorIva(float valorIva) {
        this.valorIva = valorIva;
    }

    public float getValorComIva() {
        return valorComIva;
    }

    public void setValorComIva(float valorComIva) {
        this.valorComIva = valorComIva;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getTamanhoNome() {
        return tamanhoNome;
    }

    public void setTamanhoNome(String tamanhoNome) {
        this.tamanhoNome = tamanhoNome;
    }

    public String getImagem() {
        return imagem;
    }
}
