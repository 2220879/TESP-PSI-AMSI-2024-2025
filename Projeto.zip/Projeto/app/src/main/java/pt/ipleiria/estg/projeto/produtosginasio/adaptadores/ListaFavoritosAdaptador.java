package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import static java.security.AccessController.getContext;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.ListaFavoritosFragment;
import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.CarrinhoComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritosListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class ListaFavoritosAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Favorito> favoritos;
    private FavoritosListener listener;

    public ListaFavoritosAdaptador(Context context, ArrayList<Favorito> favoritos) {
        this.context = context;
        this.favoritos = favoritos;
    }

    @Override
    public int getCount() {
        return favoritos.size();
    }

    @Override
    public Object getItem(int i) {
        return favoritos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return favoritos.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {
            view = inflater.inflate(R.layout.item_lista_favoritos, null);
        }

        ViewHolderLista viewHolder = (ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        viewHolder.update(favoritos.get(i));

        viewHolder.imgRemoveFavoritos.setOnClickListener(v -> {
            int favoritoID = favoritos.get(i).getId();
            if (listener != null) {
                listener.onProdutoDeleteFavorito(favoritoID);
            }
        });


        return view;
    }

    private class ViewHolderLista {
        private ImageView imgProduto;
        private TextView tvNomeProduto, tvPreco;
        private ImageButton imgRemoveFavoritos;

        public ViewHolderLista(View view) {
            tvNomeProduto = view.findViewById(R.id.tvNomeProduto);
            tvPreco = view.findViewById(R.id.tvPreco);
            imgProduto = view.findViewById(R.id.imgProduto);
            imgRemoveFavoritos = view.findViewById(R.id.imgRemoveFavoritos);
        }

        public void update(Favorito favorito) {
            tvNomeProduto.setText(favorito.getNomeProduto());
            tvPreco.setText(favorito.getPreco() + "€");
            Glide.with(context)
                    .load(favorito.getImagem())
                    .placeholder(R.drawable.ic_image_produto)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imgProduto);
        }

    }

    public void setListener(FavoritosListener listener) {
        this.listener = listener;
    }
}
