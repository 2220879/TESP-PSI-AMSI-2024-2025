package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import static java.security.AccessController.getContext;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.ListaFavoritosFragment;
import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class ListaFavoritosAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Favorito> favoritos;

    public ListaFavoritosAdaptador(Context context, ArrayList<Favorito> favoritos) {
        this.context = context;
        this.favoritos = favoritos;
    }

    @Override
    public int getCount() {
        return favoritos.size();
    }

    @Override
    public Object getItem(int i) {
        return favoritos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return favoritos.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        // Verifica se a view já foi criada ou precisa ser inflada
        if (view == null) {
            view = inflater.inflate(R.layout.item_lista_favoritos, viewGroup, false);
        }

        ViewHolderLista viewHolder = (ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        // Atualiza os dados da view com as informações do favorito
        Favorito favorito = favoritos.get(i);
        viewHolder.update(favorito);

        // Configura o clique do botão de remoção*****
        /*ImageButton imgRemoveFavorito = view.findViewById(R.id.imgRemoveFavoritos);
        imgRemoveFavorito.setOnClickListener(v -> onApagarFavorito(favorito,i));*/


        // Associa o botão de remoção ao clique******
        /*ImageButton imgRemoveFavorito = view.findViewById(R.id.imgRemoveFavoritos);
        imgRemoveFavorito.setOnClickListener(v -> {
            // Remove o favorito da lista local
            favoritos.remove(i);  // Remove o item na posição i da lista

            // Chama a API para remover o favorito da base de dados
            SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String IP = sharedPreferences.getString("IP", "");
            String AUTH_KEY = sharedPreferences.getString("auth_key", "");

            if (IP.isEmpty() || AUTH_KEY.isEmpty()) {
                Toast.makeText(context, "Configurações inválidas (IP ou Auth Key faltando)", Toast.LENGTH_SHORT).show();
                return;
            }

            // Chama o método para remover o favorito da API
            SingletonProdutosGinasio.getInstance(context).removerFavoritoAPI(favorito, IP, context, AUTH_KEY);

            // Notifica o adaptador que a lista foi alterada
            notifyDataSetChanged();  // Atualiza a UI para refletir a remoção
            Toast.makeText(context, "Favorito removido com sucesso!", Toast.LENGTH_SHORT).show();
        });*/

        return view;
    }

    /*public void onApagarFavorito(Favorito favorito, int i) {


        SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String IP = sharedPreferences.getString("IP", "");
        String AUTH_KEY = sharedPreferences.getString("auth_key", "");

            // Verifica se IP ou AUTH_KEY são inválidos
            if (IP.isEmpty() || AUTH_KEY.isEmpty()) {
                Toast.makeText(context, "Configurações inválidas (IP ou Auth Key faltando)", Toast.LENGTH_SHORT).show();
                return;
            }

            // Chama o método para remover o favorito da API
                SingletonProdutosGinasio.getInstance(context).removerFavoritoAPI(favorito, IP, context, AUTH_KEY);

            // Remove o favorito da lista local
            favoritos.remove(i);

            // Exibe uma mensagem de sucesso
            Toast.makeText(context, "Favorito removido com sucesso!", Toast.LENGTH_SHORT).show();
        }*/

    private class ViewHolderLista {
        private ImageView imgProduto;
        private TextView tvNomeProduto, tvPreco;

        public ViewHolderLista(View view) {
            tvNomeProduto = view.findViewById(R.id.tvNomeProduto);
            tvPreco = view.findViewById(R.id.tvPreco);
            imgProduto = view.findViewById(R.id.imgProduto);
        }

        public void update(Favorito f) {
            tvNomeProduto.setText(f.getNomeProduto());
            tvPreco.setText(String.valueOf(f.getPreco()));
            Glide.with(context)
                    .load(f.getImagem())
                    .placeholder(R.drawable.ic_image_produto)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imgProduto);
        }
    }
       /*public void update(Favorito f){
            // Obtém o produto associado ao favorito
            Produto produto = SingletonProdutosGinasio.getInstance(context).getProduto(f.getProduto_id());

            if (produto != null) {
                    // Atualiza o nome e o preço do produto
                    tvNomeProduto.setText(produto.getNomeProduto());
                    tvPreco.setText(String.format("%s €", produto.getPreco()));

                    // Carrega a imagem usando Glide
                    Glide.with(context)
                            .load(produto.getImagem()) // URL ou caminho da imagem do produto
                            .placeholder(R.drawable.ic_image_produto) // Imagem de placeholder enquanto carrega
                            .diskCacheStrategy(DiskCacheStrategy.ALL) // Cache de todas as versões da imagem
                            .into(imgProduto);
                } else {
                    // Se o produto não for encontrado, exibe valores padrão
                    tvNomeProduto.setText("Produto não encontrado");
                    tvPreco.setText("");
                    imgProduto.setImageResource(R.drawable.ic_image_produto); // Placeholder padrão
                }
            }
        }*/
}