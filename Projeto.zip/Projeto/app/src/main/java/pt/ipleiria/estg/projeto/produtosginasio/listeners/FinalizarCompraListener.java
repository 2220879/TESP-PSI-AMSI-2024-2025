package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoEntrega;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoPagamento;

public interface FinalizarCompraListener {
    void onRefreshListaMetodosPagamento(ArrayList<MetodoPagamento> metodoPagamentos);

    void onRefreshListaMetodosEntrega(ArrayList<MetodoEntrega> metodoEntregas);

    void onCodigoCupao(Map<String, String> codigoCupao);

    void onDadoscliente(Map<String, String> dadosCliente);

    void onDetalhesFinalizarCompra(Map<String, String> detalhesFinalizarCompra);
}