package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import android.content.Context;

import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.User;

public interface UserProfileListener {
    void onRefreshDetalhes(Map<String, String> dadosUserProfile);

    void onValidateAtualizar(final Context context);
}
