package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import pt.ipleiria.estg.projeto.produtosginasio.listeners.LoginListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class LoginActivity extends AppCompatActivity implements LoginListener {
    private EditText etUsername, etPassword;
    private String IP;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).setLoginListener(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
    }

    public void onClickLogin(View view) {
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");

        String username = etUsername.getText().toString();
        String password = etPassword.getText().toString();
        if (IP.isEmpty()) {
            Toast.makeText(this, "IP não configurado", Toast.LENGTH_LONG).show();
            return;
        }
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Usuário ou senha não preenchidos", Toast.LENGTH_LONG).show();
            return;
        }
        SingletonProdutosGinasio.getInstance(getApplicationContext()).loginAPI(this, IP, username, password);
    }

    public void onClickRegistar(View view) {
        Intent intent = new Intent(this, RegistoActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onValidateLogin(Context context, String auth_key) {
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.putString("auth_key", auth_key);
        editor.apply();

        Intent intent = new Intent(context, MenuMainActivity.class);
        startActivity(intent);
        finish();
    }
}