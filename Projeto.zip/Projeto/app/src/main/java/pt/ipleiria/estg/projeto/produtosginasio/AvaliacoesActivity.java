package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.AvaliacoesAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.AvaliacaoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.AvaliacoesListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Avaliacao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.LinhasCarrinho;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class AvaliacoesActivity extends AppCompatActivity implements AvaliacoesListener {
    private ListView lvAvaliacoes;
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private ArrayList<Avaliacao> listaAvaliacoes;
    private AvaliacoesAdaptador adaptador;
    public static final String AvaliacaoID = "AvaliacaoID";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avaliacoes);

        setTitle("Avaliações");

        lvAvaliacoes = findViewById(R.id.lvAvaliacoes);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        atualizarvista();

        lvAvaliacoes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), DetalhesAvaliacaoActivity.class);
                intent.putExtra(AvaliacaoID, (int) l);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onRefreshAvaliacoes(ArrayList<Avaliacao> avaliacoes) {
        if (avaliacoes != null) {
            listaAvaliacoes = avaliacoes;
            adaptador = new AvaliacoesAdaptador(getApplicationContext(), listaAvaliacoes);
            lvAvaliacoes.setAdapter(adaptador);
        }
    }

    private void atualizarvista() {
        SingletonProdutosGinasio.getInstance(getApplicationContext()).setAvaliacoesListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getAvaliacoesClienteAPI(getApplicationContext(), IP, AUTH_KEY);
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizarvista();
    }
}