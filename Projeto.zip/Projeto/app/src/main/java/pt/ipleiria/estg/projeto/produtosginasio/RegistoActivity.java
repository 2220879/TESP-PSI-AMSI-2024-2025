package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import pt.ipleiria.estg.projeto.produtosginasio.listeners.RegistoListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.User;

public class RegistoActivity extends AppCompatActivity implements RegistoListener {
    private EditText etUsername, etEmail, etPassword, etNif, etMorada, etTelefone;
    SharedPreferences sharedPreferences;
    private String IP;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registo);

        SingletonProdutosGinasio.getInstance(getApplicationContext()).setRegistoListener(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etEmail = findViewById(R.id.etEmail);
        etNif = findViewById(R.id.etNif);
        etMorada = findViewById(R.id.etMorada);
        etTelefone = findViewById(R.id.etTelefone);
    }

    public void onClickRegistar(View view) {
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");

        String username = etUsername.getText().toString();
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();
        int nif = Integer.parseInt(etNif.getText().toString());
        String morada = etMorada.getText().toString();
        int telefone = Integer.parseInt(etTelefone.getText().toString());

        user = new User(0, username, email, password, nif, morada, telefone);

        SingletonProdutosGinasio.getInstance(getApplicationContext()).registoUserAPI(this, IP, user);
    }

    @Override
    public void onValidateRegister(Context context) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    public void onClickCancelarRegisto(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}