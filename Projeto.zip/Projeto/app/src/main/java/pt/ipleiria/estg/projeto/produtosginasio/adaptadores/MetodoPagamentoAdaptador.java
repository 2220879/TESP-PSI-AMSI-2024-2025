package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoPagamento;

public class MetodoPagamentoAdaptador extends ArrayAdapter<MetodoPagamento> {
    private Context context;
    private ArrayList<MetodoPagamento> metodoPagamentos;

    public MetodoPagamentoAdaptador(Context context, ArrayList<MetodoPagamento> metodoPagamentos) {
        super(context, android.R.layout.simple_spinner_item, metodoPagamentos);
        this.context = context;
        this.metodoPagamentos = metodoPagamentos;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(android.R.layout.simple_spinner_item, parent, false);
        }

        MetodoPagamento metodoPagamento = metodoPagamentos.get(position);

        TextView textView = convertView.findViewById(android.R.id.text1);
        textView.setText(metodoPagamento.getMetodoPagamento());

        return convertView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }

        MetodoPagamento metodoPagamento = metodoPagamentos.get(position);

        TextView textView = convertView.findViewById(android.R.id.text1);
        textView.setText(metodoPagamento.getMetodoPagamento());

        return convertView;
    }
}