package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class Tamanho {
    private int id;
    private String referencia;

    public Tamanho(int id, String referencia) {
        this.id = id;
        this.referencia = referencia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }
}
