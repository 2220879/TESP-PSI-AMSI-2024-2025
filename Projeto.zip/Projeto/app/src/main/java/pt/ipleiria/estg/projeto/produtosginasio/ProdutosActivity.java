package pt.ipleiria.estg.projeto.produtosginasio;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

public class ProdutosActivity extends AppCompatActivity {
    private ImageButton btnLista, btnGrelha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produtos);
        setTitle("Produtos");

        btnLista = findViewById(R.id.btnLista);
        btnGrelha = findViewById(R.id.btnGrelha);

        //verifica se o fragmento já está carregado ou não
        if (savedInstanceState == null) {
            // Se não, carrega o fragmento ListaProdutosFragment por padrão
            loadFragment(new ListaProdutosFragment());
        }

        //troca para o fragmento de lista produtos
        btnLista.setOnClickListener(v -> loadFragment(new ListaProdutosFragment()));

        //troca para o fragmento grelha produtos
        btnGrelha.setOnClickListener(v -> loadFragment(new GrelhaProdutosFragment()));
    }

    //carregar o o tipo de visualização de produtos pretendido
    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentView, fragment)
                .commit();
    }
}