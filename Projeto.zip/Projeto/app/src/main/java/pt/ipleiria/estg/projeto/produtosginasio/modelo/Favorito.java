package pt.ipleiria.estg.projeto.produtosginasio.modelo;

import android.content.Context;

public class Favorito {
    private int id, produto_id, profile_id;

    private String nomeProduto;
    private float preco;
    private String imagem;

    public Favorito(int id,int produto_id ,int profile_id,String nomeProduto,float preco,String imagem){
        this.id = id;
        this.profile_id = profile_id;
        this.produto_id = produto_id;
        this.nomeProduto= nomeProduto;
        this.imagem= imagem;
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProfile_id() {
        return profile_id;
    }

    public void setProfile_id(int profile_id) {
        this.profile_id = profile_id;
    }

    public int getProduto_id() {
        return produto_id;
    }

    public void setProduto_id(int produto_id) {
        this.produto_id = produto_id;
    }


    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

}

