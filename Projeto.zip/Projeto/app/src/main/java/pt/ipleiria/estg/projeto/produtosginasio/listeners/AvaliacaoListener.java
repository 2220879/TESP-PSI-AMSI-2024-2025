package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import android.content.Context;

public interface AvaliacaoListener {
    void onValidateRegister(final Context context);
}
