package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.CarrinhoComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.LinhasCarrinho;

public class CarrinhoComprasAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<LinhasCarrinho> linhasCarrinhos;
    private CarrinhoComprasListener listener;

    public CarrinhoComprasAdaptador(Context context, ArrayList<LinhasCarrinho> linhasCarrinhos) {
        this.context = context;
        this.linhasCarrinhos = linhasCarrinhos;
    }

    @Override
    public int getCount() {
        return linhasCarrinhos.size();
    }

    @Override
    public Object getItem(int i) {
        return linhasCarrinhos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return linhasCarrinhos.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {
            view = inflater.inflate(R.layout.item_carrinho_de_compras, null);
        }

        ViewHolderLista viewHolder = (ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        viewHolder.update(linhasCarrinhos.get(i));

        viewHolder.btnAddQuantidade.setOnClickListener(v -> {
            int linhaCarrinho = linhasCarrinhos.get(i).getId();

            if (listener != null) {
                listener.onProdutoAddQuantidade(linhaCarrinho);
            }
        });

        viewHolder.btnRemoveQuantidade.setOnClickListener(v -> {
            int linhaCarrinho = linhasCarrinhos.get(i).getId();

            if (listener != null) {
                listener.onProdutoRemoveQuantidade(linhaCarrinho);
            }
        });

        viewHolder.btnApagarProduto.setOnClickListener(v -> {
            int linhaCarrinho = linhasCarrinhos.get(i).getId();

            if (listener != null) {
                listener.onProdutoRemovido(linhaCarrinho);
            }
        });

        return view;
    }

    private class ViewHolderLista {
        private ImageView imgProduto;
        private TextView tvNomeProduto, tvPreco, tvTamanhoProduto, tvQuantidadeProduto;
        private ImageButton btnAddQuantidade, btnRemoveQuantidade, btnApagarProduto;

        public ViewHolderLista(View view) {
            tvNomeProduto = view.findViewById(R.id.tvNomeProduto);
            tvPreco = view.findViewById(R.id.tvPreco);
            tvTamanhoProduto = view.findViewById(R.id.tvTamanhoProduto);
            tvQuantidadeProduto = view.findViewById(R.id.tvQuantidadeProduto);
            imgProduto = view.findViewById(R.id.imgProduto);
            btnAddQuantidade = view.findViewById(R.id.btnAddQuantidade);
            btnRemoveQuantidade = view.findViewById(R.id.btnRemoveQuantidade);
            btnApagarProduto = view.findViewById(R.id.btnApagarProduto);
        }

        public void update(LinhasCarrinho lc) {
            tvNomeProduto.setText(lc.getNomeProduto());
            tvPreco.setText(lc.getSubtotal() + " €");
            tvTamanhoProduto.setText(lc.getTamanhoNome());
            tvQuantidadeProduto.setText(String.valueOf(lc.getQuantidade()));
            Glide.with(context)
                    .load(lc.getImagem())
                    .placeholder(R.drawable.ic_image_produto)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imgProduto);
        }
    }

    public void setListener(CarrinhoComprasListener listener) {
        this.listener = listener;
    }
}