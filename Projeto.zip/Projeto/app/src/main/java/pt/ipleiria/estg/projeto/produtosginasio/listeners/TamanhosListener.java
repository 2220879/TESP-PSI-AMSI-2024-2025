package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Tamanho;

public interface TamanhosListener {
    void onListaTamanhos(ArrayList<Tamanho> listaTamanhos);
}
