package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.listeners.AvaliacaoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutoListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Avaliacao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class DetalhesProdutoActivity extends AppCompatActivity implements ProdutoListener, FavoritoListener, AvaliacaoListener {

    private TextView tvNome, tvPreco, tvDescricao, tvMarca, tvCategoria, tvGenero, tvIva, etAvaliacao;
    private ImageView imgProduto;
    private Produto produto;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_produto);

        id = getIntent().getIntExtra(ListaProdutosFragment.ProdutoId, 0);
        produto = SingletonProdutosGinasio.getInstance(getApplicationContext()).getProduto(id);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).setProdutoListener(this);
        tvNome = findViewById(R.id.tvNome);
        tvPreco = findViewById(R.id.tvPreco);
        tvDescricao = findViewById(R.id.tvDescricao);
        tvMarca = findViewById(R.id.tvMarca);
        tvCategoria = findViewById(R.id.tvCategoria);
        tvGenero = findViewById(R.id.tvGenero);
        tvIva = findViewById(R.id.tvIva);
        imgProduto = findViewById(R.id.imgProduto);

        etAvaliacao = findViewById(R.id.etAvaliacao);

        carregarProduto();
    }

    private void carregarProduto() {
        setTitle("Detalhes:" + produto.getNomeProduto());
        tvNome.setText(produto.getNomeProduto());
        tvPreco.setText(produto.getPreco() + "€");
        tvDescricao.setText(produto.getDescricaoProduto());
        tvMarca.setText(produto.getMarca());
        tvCategoria.setText(produto.getCategoria());
        tvGenero.setText(produto.getGenero());
        tvIva.setText(produto.getIva() + "");
        Glide.with(getApplicationContext())
                .load(produto.getImagem())
                .placeholder(R.drawable.ic_image_produto)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(imgProduto);
    }

    @Override
    public void onRefreshDetalhes(int operacaoDetalhes) {
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }

    public void onAdicionarFavorito(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        int profile_id = sharedPreferences.getInt("profile_id", -1);

        // Verifica se o usuário está autenticado
        if (profile_id == -1) {
            Toast.makeText(this, "Usuário não autenticado", Toast.LENGTH_SHORT).show();
            return;
        }

        // Recupera o IP e o auth_key das preferências
        String ip = sharedPreferences.getString("IP", "");
        String authKey = sharedPreferences.getString("auth_key", "");

        // Verifica se o IP e auth_key são válidos
        if (ip.isEmpty() || authKey.isEmpty()) {
            Toast.makeText(this, "Configurações inválidas (IP ou Auth Key faltando)", Toast.LENGTH_SHORT).show();
            return;
        }

        Favorito favorito = new Favorito(0, produto.getId(), profile_id, produto.getNomeProduto(), produto.getPreco(), produto.getImagem());


        SingletonProdutosGinasio.getInstance(getApplicationContext()).setFavoritoListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).adicionarFavoritoAPI(favorito, ip, this, authKey);

        Toast.makeText(this, "Produto adicionado aos favoritos", Toast.LENGTH_SHORT).show();
    }

    public void onCriarAvaliacao(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        // Recupera o IP e o auth_key das preferências
        String ip = sharedPreferences.getString("IP", "");
        String authKey = sharedPreferences.getString("auth_key", "");
        int profile_id = sharedPreferences.getInt("profile_id", -1);

        String conteudoAvaliacao = etAvaliacao.getText().toString();

        Avaliacao avaliacao = new Avaliacao(0, conteudoAvaliacao, produto.getId(), profile_id);


        SingletonProdutosGinasio.getInstance(getApplicationContext()).setAvaliacaoListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).registoAvaliacaoAPI(getApplicationContext(), ip, authKey, avaliacao);
    }

    public void onValidateRegister(Context context) {
        Toast.makeText(this, "Avaliação criada com sucesso!", Toast.LENGTH_SHORT).show();
    }
}