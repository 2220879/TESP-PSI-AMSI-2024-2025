package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import android.content.Context;

public interface RegistoListener {
    void onValidateRegister(final Context context);
}
