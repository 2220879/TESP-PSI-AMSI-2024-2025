package pt.ipleiria.estg.projeto.produtosginasio.listeners;

public interface FavoritoListener {
    void onRefreshDetalhes(int operacaoDetalhes);
}
