package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.DetalhesEncomendaAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.DetalhesEncomendaListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.DetalhesEncomenda;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Encomenda;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.ProdutoDetalhes;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class DetalhesDeEncomendasActivity extends AppCompatActivity implements DetalhesEncomendaListener {
    private TextView tvData, tvHora, tvMorada, tvTelefone, tvEmail, tvEstadoencomenda;
    private ListView lvDetalhesEncomendas;
    private DetalhesEncomenda detalhesEncomenda;
    private String IP, AUTH_KEY;
    private int encomendaID;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_de_encomendas);

        encomendaID = getIntent().getIntExtra("EncomendaId", 0);

        tvData = findViewById(R.id.tvData);
        tvHora = findViewById(R.id.tvHora);
        tvMorada = findViewById(R.id.tvMorada);
        tvTelefone = findViewById(R.id.tvTelefone);
        tvEmail = findViewById(R.id.tvEmail);
        tvEstadoencomenda = findViewById(R.id.tvEstadoencomenda);
        lvDetalhesEncomendas = findViewById(R.id.lvDetalhesEncomendas);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getApplicationContext()).getDetalhesEncomendaAPI(getApplicationContext(), IP, AUTH_KEY, encomendaID);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).setDetalhesEncomendaListener(this);

    }

    private void carregarDetalhesEncomenda() {
        setTitle("Encomenda Nº " + detalhesEncomenda.getId());
        tvData.setText(detalhesEncomenda.getData());
        tvHora.setText(detalhesEncomenda.getHora());
        tvMorada.setText(detalhesEncomenda.getMorada());
        tvTelefone.setText(String.valueOf(detalhesEncomenda.getTelefone())); // Convertendo telefone para string
        tvEmail.setText(detalhesEncomenda.getEmail());
        tvEstadoencomenda.setText(detalhesEncomenda.getEstadoEncomenda());

        DetalhesEncomendaAdaptador adapter = new DetalhesEncomendaAdaptador(this, detalhesEncomenda.getProdutos());
        lvDetalhesEncomendas.setAdapter(adapter);
    }

    @Override
    public void onRefreshDetalhes(DetalhesEncomenda detalhes) {
        if (detalhes != null) {
            detalhesEncomenda = detalhes;  // Atualiza a variável com os dados carregados
            carregarDetalhesEncomenda();  // Agora que os dados estão disponíveis, carregue os detalhes
        } else {
            //Caso os dados não tenham sido carregados corretamente
            Toast.makeText(this, "Erro ao carregar os detalhes da encomenda", Toast.LENGTH_SHORT).show();
        }
    }
}