package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;

public interface FavoritosListener {
    void onRefresListaFavoritos(ArrayList<Favorito> listaFavoritos);

    void onProdutoDeleteFavorito(int favoritoID);
}

