package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutosListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class ListaProdutosFragment extends Fragment implements ProdutosListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private ListaProdutosAdaptador adaptador;
    private ListView lvProdutos;
    public static final String ProdutoId = "ProdutoID";
    private ArrayList<Produto> produtos;


    public ListaProdutosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_produtos, container, false);
        setHasOptionsMenu(true);
        lvProdutos = view.findViewById(R.id.lvProdutos);

        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getContext()).setProdutosListener(this);
        SingletonProdutosGinasio.getInstance(getContext()).getAllProdutosAPI(getContext(), IP, AUTH_KEY);

        //ao clicar no produto na lista de produtos abre os detalhes do produto
        lvProdutos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getContext(),DetalhesProdutoActivity.class);
                intent.putExtra(ProdutoId,(int) l);
                startActivity(intent);
            }
        });

        return view;
    }

    @Override
    public void onClick(View view) {
        Intent intent= new Intent(getContext(), DetalhesProdutoActivity.class);
        startActivity(intent);
    }

    @Override
    public void onRefreshListaProdutos(ArrayList<Produto> listaProdutos) {
        if (listaProdutos != null) {
            lvProdutos.setAdapter(new ListaProdutosAdaptador(getContext(), listaProdutos));
        }
    }
}