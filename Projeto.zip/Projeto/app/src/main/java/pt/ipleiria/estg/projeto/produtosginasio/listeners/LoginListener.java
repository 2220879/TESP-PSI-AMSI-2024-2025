package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import android.content.Context;

public interface LoginListener {
    void onValidateLogin(final Context context, final String auth_key, final String username, final String email, final int profile_id);
}
