package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.HistoricoComprasAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.HistoricoEncomendasAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.EncomendasListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Encomenda;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class HistoricoDeEncomendasActivity extends AppCompatActivity implements EncomendasListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private HistoricoEncomendasAdaptador adaptador;
    private ListView lvHistoricoEncomendas;
    public static final String EncomendaId = "EncomendaId";
    private ArrayList<Encomenda> encomendas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico_de_encomendas);
        setTitle("Minhas Encomendas");

        lvHistoricoEncomendas = findViewById(R.id.lvHistoricoEncomendas);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getApplicationContext()).setEncomendasListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getEncomendasAPI(getApplicationContext(), IP, AUTH_KEY);

        //ao clicar no produto na lista de produtos abre os detalhes do produto
        lvHistoricoEncomendas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), DetalhesDeEncomendasActivity.class);
                intent.putExtra(EncomendaId, (int) l);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onRefreshEncomendas(ArrayList<Encomenda> listaEncomendas) {
        if (listaEncomendas != null) {
            lvHistoricoEncomendas.setAdapter(new HistoricoEncomendasAdaptador(getApplicationContext(), listaEncomendas));
        }
    }
}