package pt.ipleiria.estg.projeto.produtosginasio;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class HistoricoDeEncomendasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico_de_encomendas);
    }
}