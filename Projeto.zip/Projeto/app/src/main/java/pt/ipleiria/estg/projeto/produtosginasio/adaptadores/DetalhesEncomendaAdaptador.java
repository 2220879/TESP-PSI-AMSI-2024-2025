package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.ProdutoDetalhes;

public class DetalhesEncomendaAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<ProdutoDetalhes> produtos;

    public DetalhesEncomendaAdaptador(Context context, ArrayList<ProdutoDetalhes> produtos) {
        this.context = context;
        this.produtos = produtos;
    }

    @Override
    public int getCount() {
        return produtos.size();
    }

    @Override
    public Object getItem(int position) {
        return produtos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {
            view = inflater.inflate(R.layout.item_lista_detalhes_de_encomendas, null);
        }

        ViewHolderLista viewHolder = (ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        //apresenta os produtos na vista
        viewHolder.update(produtos.get(i));

        return view;
    }

    private class ViewHolderLista {
        private TextView tvNomeProduto, tvPreco, tvQuantidade;

        public ViewHolderLista(View view) {
            tvNomeProduto = view.findViewById(R.id.tvNomeProduto);
            tvPreco = view.findViewById(R.id.tvPreco);
            tvQuantidade = view.findViewById(R.id.tvQuantidade);
        }

        public void update(ProdutoDetalhes produto) {
            tvNomeProduto.setText(produto.getNomeProduto());
            tvPreco.setText(String.format(Locale.getDefault(), "%.2f€", produto.getPreco()));
            tvQuantidade.setText(String.valueOf(produto.getQuantidade()));
        }
    }
}
