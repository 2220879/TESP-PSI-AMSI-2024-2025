package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class Compra {
    private int id, nif, metodoPagamento, metodoEntrega, encomendaID, profileID;
    private float valorTotal, ivaTotal;
    private String dataEmissao, horaEmissao;

    public Compra(int id, String dataEmissao, String horaEmissao, float valorTotal, float ivaTotal, int nif, int metodoPagamento, int metodoEntrega, int encomendaID, int profileID) {
        this.id = id;
        this.dataEmissao = dataEmissao;
        this.horaEmissao = horaEmissao;
        this.valorTotal = valorTotal;
        this.ivaTotal = ivaTotal;
        this.nif = nif;
        this.metodoPagamento = metodoPagamento;
        this.metodoEntrega = metodoEntrega;
        this.encomendaID = encomendaID;
        this.profileID = profileID;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNif() {
        return nif;
    }

    public void setNif(int nif) {
        this.nif = nif;
    }

    public int getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(int metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public int getMetodoEntrega() {
        return metodoEntrega;
    }

    public void setMetodoEntrega(int metodoEntrega) {
        this.metodoEntrega = metodoEntrega;
    }

    public int getEncomendaID() {
        return encomendaID;
    }

    public void setEncomendaID(int encomendaID) {
        this.encomendaID = encomendaID;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public float getIvaTotal() {
        return ivaTotal;
    }

    public void setIvaTotal(float ivaTotal) {
        this.ivaTotal = ivaTotal;
    }

    public String getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(String dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public String getHoraEmissao() {
        return horaEmissao;
    }

    public void setHoraEmissao(String horaEmissao) {
        this.horaEmissao = horaEmissao;
    }

    public int getProfileID() {
        return profileID;
    }

    public void setProfileID(int profileID) {
        this.profileID = profileID;
    }
}