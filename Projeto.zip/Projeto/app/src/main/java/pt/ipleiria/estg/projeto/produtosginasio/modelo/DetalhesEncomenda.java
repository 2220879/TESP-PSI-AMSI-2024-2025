package pt.ipleiria.estg.projeto.produtosginasio.modelo;

import java.util.ArrayList;

public class DetalhesEncomenda {
    private int id, telefone, profile_id;
    private String data, hora, morada, email, estadoEncomenda;
    private ArrayList<ProdutoDetalhes> produtos;

    public DetalhesEncomenda(int id, String data, String hora, String morada, int telefone, String email, String estadoEncomenda, int profile_id, ArrayList<ProdutoDetalhes> produtos) {
        this.id = id;
        this.data = data;
        this.hora = hora;
        this.morada = morada;
        this.telefone = telefone;
        this.email = email;
        this.estadoEncomenda = estadoEncomenda;
        this.profile_id = profile_id;
        this.produtos = produtos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public int getProfile_id() {
        return profile_id;
    }

    public void setProfile_id(int profile_id) {
        this.profile_id = profile_id;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEstadoEncomenda() {
        return estadoEncomenda;
    }

    public void setEstadoEncomenda(String estadoEncomenda) {
        this.estadoEncomenda = estadoEncomenda;
    }

    public ArrayList<ProdutoDetalhes> getProdutos() {
        return produtos;
    }
}
