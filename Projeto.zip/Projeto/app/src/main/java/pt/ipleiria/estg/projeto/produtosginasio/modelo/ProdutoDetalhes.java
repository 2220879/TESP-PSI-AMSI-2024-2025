package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class ProdutoDetalhes {
    private String nomeProduto;
    private float preco;
    private int quantidade;

    public ProdutoDetalhes(String nomeProduto, float preco, int quantidade) {
        this.nomeProduto = nomeProduto;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public float getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }
}
