package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaFavoritosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritosListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class ListaFavoritosFragment extends Fragment implements FavoritosListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private ListView lvFavoritos;
    private ArrayList<Favorito> favoritos;
    public static final String ProdutoID= "ProdutoID";
    public static final int ADD=100,DELETE=200;

    public ListaFavoritosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_lista_favoritos, container, false);
        setHasOptionsMenu(true);
        lvFavoritos=view.findViewById(R.id.lvFavoritos);
        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getContext()).setFavoritosListener(this);
        SingletonProdutosGinasio.getInstance(getContext()).getAllFavoritosApi(getContext(), IP, AUTH_KEY);

        lvFavoritos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Favorito favorito = (Favorito) adapterView.getItemAtPosition(i);

                if (favorito != null) {
                    Intent intent = new Intent(getContext(), DetalhesProdutoActivity.class);
                    intent.putExtra(ProdutoID, favorito.getProduto_id());
                    startActivity(intent);
                } else {
                    Toast.makeText(getContext(), "Erro ao recuperar produto favorito", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            SingletonProdutosGinasio.getInstance(getContext()).getAllFavoritosApi(getContext(), IP, AUTH_KEY);

            if (requestCode == ADD) {
                Toast.makeText(getContext(), "Favorito adicionado com sucesso", Toast.LENGTH_LONG).show();
            }
        }
    }

   /* public void onApagarFavorito(View view){
        int position = lvFavoritos.getPositionForView(view);
    if (position != ListView.INVALID_POSITION) {
        Favorito favorito = favoritos.get(position);

        SharedPreferences sharedPreferences = getContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String IP = sharedPreferences.getString("IP", "");
        String AUTH_KEY = sharedPreferences.getString("auth_key", "");

        // Verifica se IP ou AUTH_KEY são inválidos
        if (IP.isEmpty() || AUTH_KEY.isEmpty()) {
            Toast.makeText(getContext(), "Configurações inválidas (IP ou Auth Key faltando)", Toast.LENGTH_SHORT).show();
            return;
        }
        // Chama a função para remover o favorito na API
        SingletonProdutosGinasio.getInstance(getContext()).removerFavoritoAPI(favorito, IP, getContext(), AUTH_KEY);

        // Remove o favorito da lista local
        favoritos.remove(position);  // Remove o item da posição correta
        //notifyDataSetChanged(); // Atualiza a interface

        // Exibe a mensagem de sucesso
        Toast.makeText(getContext(), "Favorito removido com sucesso!", Toast.LENGTH_SHORT).show();
        // Notifica o Listener para atualizar a lista

    }
    }*/

   /*public void onApagarFavorito(View view) {
        // Obtém a posição do item na lista
    int position = lvFavoritos.getPositionForView(view);

    // Verifica se a posição é válida
    if (position != ListView.INVALID_POSITION) {

        // Obtém o favorito correspondente à posição
        Favorito favorito = favoritos.get(position);

        // Obtém o IP e o AUTH_KEY das preferências
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String IP = sharedPreferences.getString("IP", "");
        String AUTH_KEY = sharedPreferences.getString("auth_key", "");

        // Verifica se IP ou AUTH_KEY são inválidos
        if (IP.isEmpty() || AUTH_KEY.isEmpty()) {
            Toast.makeText(getContext(), "Configurações inválidas (IP ou Auth Key faltando)", Toast.LENGTH_SHORT).show();
            return;
        }

        // Chama o método para remover o favorito da API
        SingletonProdutosGinasio.getInstance(getContext()).removerFavoritoAPI(favorito, IP, getContext(), AUTH_KEY);

        // Remove o favorito da lista local
        favoritos.remove(position);

        // Exibe uma mensagem de sucesso
        Toast.makeText(getContext(), "Favorito removido com sucesso!", Toast.LENGTH_SHORT).show();
    }
    }*/





    @Override
    public void onRefresListaFavoritos(ArrayList<Favorito> listaFavoritos) {
        if(listaFavoritos != null){
            lvFavoritos.setAdapter(new ListaFavoritosAdaptador(getContext(),listaFavoritos));

        }else{
            Toast.makeText(getContext(),"Nenhum favorito",Toast.LENGTH_LONG).show();
        }
    }
}