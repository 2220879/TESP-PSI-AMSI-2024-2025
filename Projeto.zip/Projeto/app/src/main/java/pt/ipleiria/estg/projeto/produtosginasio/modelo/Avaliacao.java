package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class Avaliacao {
    private int id, produto_id, profile_id;
    private String descricao;

    public Avaliacao(int id, String descricao, int produto_id, int profile_id) {
        this.id = id;
        this.descricao = descricao;
        this.produto_id = produto_id;
        this.profile_id = profile_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProduto_id() {
        return produto_id;
    }

    public void setProduto_id(int produto_id) {
        this.produto_id = produto_id;
    }

    public int getProfile_id() {
        return profile_id;
    }

    public void setProfile_id(int profile_id) {
        this.profile_id = profile_id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
