package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class Avaliacao {
    private int id, produto_id, profile_id;
    private String descricao, nomeProduto, imagemProduto;

    public Avaliacao(int id, String descricao, String nomeProduto, String imagemProduto, int produto_id, int profile_id) {
        this.id = id;
        this.descricao = descricao;
        this.nomeProduto = nomeProduto;
        this.imagemProduto = imagemProduto;
        this.produto_id = produto_id;
        this.profile_id = profile_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProduto_id() {
        return produto_id;
    }

    public void setProduto_id(int produto_id) {
        this.produto_id = produto_id;
    }

    public int getProfile_id() {
        return profile_id;
    }

    public void setProfile_id(int profile_id) {
        this.profile_id = profile_id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getImagemProduto() {
        return imagemProduto;
    }

    public void setImagemProduto(String imagemProduto) {
        this.imagemProduto = imagemProduto;
    }
}
